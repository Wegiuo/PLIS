/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "C:/Users/RauzHalzo/Desktop/LR4/DECODER.v";
static unsigned int ng1[] = {7U, 0U};
static unsigned int ng2[] = {127U, 0U};
static unsigned int ng3[] = {6U, 0U};
static unsigned int ng4[] = {191U, 0U};
static unsigned int ng5[] = {5U, 0U};
static unsigned int ng6[] = {223U, 0U};
static unsigned int ng7[] = {4U, 0U};
static unsigned int ng8[] = {239U, 0U};
static unsigned int ng9[] = {3U, 0U};
static unsigned int ng10[] = {247U, 0U};
static unsigned int ng11[] = {2U, 0U};
static unsigned int ng12[] = {251U, 0U};
static unsigned int ng13[] = {1U, 0U};
static unsigned int ng14[] = {253U, 0U};
static unsigned int ng15[] = {0U, 0U};
static unsigned int ng16[] = {254U, 0U};



static void Always_8_0(char *t0)
{
    char t7[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    int t6;
    char *t8;
    char *t9;
    char *t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    char *t19;

LAB0:    t1 = (t0 + 2368U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(8, ng0);
    t2 = (t0 + 2688);
    *((int *)t2) = 1;
    t3 = (t0 + 2400);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(9, ng0);
    t4 = (t0 + 1048U);
    t5 = *((char **)t4);

LAB5:    t4 = ((char*)((ng1)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 3, t4, 4);
    if (t6 == 1)
        goto LAB6;

LAB7:    t2 = ((char*)((ng3)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 3, t2, 4);
    if (t6 == 1)
        goto LAB8;

LAB9:    t2 = ((char*)((ng5)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 3, t2, 4);
    if (t6 == 1)
        goto LAB10;

LAB11:    t2 = ((char*)((ng7)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 3, t2, 4);
    if (t6 == 1)
        goto LAB12;

LAB13:    t2 = ((char*)((ng9)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 3, t2, 4);
    if (t6 == 1)
        goto LAB14;

LAB15:    t2 = ((char*)((ng11)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 3, t2, 4);
    if (t6 == 1)
        goto LAB16;

LAB17:    t2 = ((char*)((ng13)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 3, t2, 4);
    if (t6 == 1)
        goto LAB18;

LAB19:    t2 = ((char*)((ng15)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 3, t2, 4);
    if (t6 == 1)
        goto LAB20;

LAB21:
LAB22:    goto LAB2;

LAB6:    xsi_set_current_line(10, ng0);
    t8 = ((char*)((ng2)));
    memset(t7, 0, 8);
    t9 = (t7 + 4);
    t10 = (t8 + 4);
    t11 = *((unsigned int *)t8);
    t12 = (~(t11));
    *((unsigned int *)t7) = t12;
    *((unsigned int *)t9) = 0;
    if (*((unsigned int *)t10) != 0)
        goto LAB24;

LAB23:    t17 = *((unsigned int *)t7);
    *((unsigned int *)t7) = (t17 & 255U);
    t18 = *((unsigned int *)t9);
    *((unsigned int *)t9) = (t18 & 255U);
    t19 = (t0 + 1448);
    xsi_vlogvar_assign_value(t19, t7, 0, 0, 8);
    goto LAB22;

LAB8:    xsi_set_current_line(11, ng0);
    t3 = ((char*)((ng4)));
    memset(t7, 0, 8);
    t4 = (t7 + 4);
    t8 = (t3 + 4);
    t11 = *((unsigned int *)t3);
    t12 = (~(t11));
    *((unsigned int *)t7) = t12;
    *((unsigned int *)t4) = 0;
    if (*((unsigned int *)t8) != 0)
        goto LAB26;

LAB25:    t17 = *((unsigned int *)t7);
    *((unsigned int *)t7) = (t17 & 255U);
    t18 = *((unsigned int *)t4);
    *((unsigned int *)t4) = (t18 & 255U);
    t9 = (t0 + 1448);
    xsi_vlogvar_assign_value(t9, t7, 0, 0, 8);
    goto LAB22;

LAB10:    xsi_set_current_line(12, ng0);
    t3 = ((char*)((ng6)));
    memset(t7, 0, 8);
    t4 = (t7 + 4);
    t8 = (t3 + 4);
    t11 = *((unsigned int *)t3);
    t12 = (~(t11));
    *((unsigned int *)t7) = t12;
    *((unsigned int *)t4) = 0;
    if (*((unsigned int *)t8) != 0)
        goto LAB28;

LAB27:    t17 = *((unsigned int *)t7);
    *((unsigned int *)t7) = (t17 & 255U);
    t18 = *((unsigned int *)t4);
    *((unsigned int *)t4) = (t18 & 255U);
    t9 = (t0 + 1448);
    xsi_vlogvar_assign_value(t9, t7, 0, 0, 8);
    goto LAB22;

LAB12:    xsi_set_current_line(13, ng0);
    t3 = ((char*)((ng8)));
    memset(t7, 0, 8);
    t4 = (t7 + 4);
    t8 = (t3 + 4);
    t11 = *((unsigned int *)t3);
    t12 = (~(t11));
    *((unsigned int *)t7) = t12;
    *((unsigned int *)t4) = 0;
    if (*((unsigned int *)t8) != 0)
        goto LAB30;

LAB29:    t17 = *((unsigned int *)t7);
    *((unsigned int *)t7) = (t17 & 255U);
    t18 = *((unsigned int *)t4);
    *((unsigned int *)t4) = (t18 & 255U);
    t9 = (t0 + 1448);
    xsi_vlogvar_assign_value(t9, t7, 0, 0, 8);
    goto LAB22;

LAB14:    xsi_set_current_line(14, ng0);
    t3 = ((char*)((ng10)));
    memset(t7, 0, 8);
    t4 = (t7 + 4);
    t8 = (t3 + 4);
    t11 = *((unsigned int *)t3);
    t12 = (~(t11));
    *((unsigned int *)t7) = t12;
    *((unsigned int *)t4) = 0;
    if (*((unsigned int *)t8) != 0)
        goto LAB32;

LAB31:    t17 = *((unsigned int *)t7);
    *((unsigned int *)t7) = (t17 & 255U);
    t18 = *((unsigned int *)t4);
    *((unsigned int *)t4) = (t18 & 255U);
    t9 = (t0 + 1448);
    xsi_vlogvar_assign_value(t9, t7, 0, 0, 8);
    goto LAB22;

LAB16:    xsi_set_current_line(15, ng0);
    t3 = ((char*)((ng12)));
    memset(t7, 0, 8);
    t4 = (t7 + 4);
    t8 = (t3 + 4);
    t11 = *((unsigned int *)t3);
    t12 = (~(t11));
    *((unsigned int *)t7) = t12;
    *((unsigned int *)t4) = 0;
    if (*((unsigned int *)t8) != 0)
        goto LAB34;

LAB33:    t17 = *((unsigned int *)t7);
    *((unsigned int *)t7) = (t17 & 255U);
    t18 = *((unsigned int *)t4);
    *((unsigned int *)t4) = (t18 & 255U);
    t9 = (t0 + 1448);
    xsi_vlogvar_assign_value(t9, t7, 0, 0, 8);
    goto LAB22;

LAB18:    xsi_set_current_line(16, ng0);
    t3 = ((char*)((ng14)));
    memset(t7, 0, 8);
    t4 = (t7 + 4);
    t8 = (t3 + 4);
    t11 = *((unsigned int *)t3);
    t12 = (~(t11));
    *((unsigned int *)t7) = t12;
    *((unsigned int *)t4) = 0;
    if (*((unsigned int *)t8) != 0)
        goto LAB36;

LAB35:    t17 = *((unsigned int *)t7);
    *((unsigned int *)t7) = (t17 & 255U);
    t18 = *((unsigned int *)t4);
    *((unsigned int *)t4) = (t18 & 255U);
    t9 = (t0 + 1448);
    xsi_vlogvar_assign_value(t9, t7, 0, 0, 8);
    goto LAB22;

LAB20:    xsi_set_current_line(17, ng0);
    t3 = ((char*)((ng16)));
    memset(t7, 0, 8);
    t4 = (t7 + 4);
    t8 = (t3 + 4);
    t11 = *((unsigned int *)t3);
    t12 = (~(t11));
    *((unsigned int *)t7) = t12;
    *((unsigned int *)t4) = 0;
    if (*((unsigned int *)t8) != 0)
        goto LAB38;

LAB37:    t17 = *((unsigned int *)t7);
    *((unsigned int *)t7) = (t17 & 255U);
    t18 = *((unsigned int *)t4);
    *((unsigned int *)t4) = (t18 & 255U);
    t9 = (t0 + 1448);
    xsi_vlogvar_assign_value(t9, t7, 0, 0, 8);
    goto LAB22;

LAB24:    t13 = *((unsigned int *)t7);
    t14 = *((unsigned int *)t10);
    *((unsigned int *)t7) = (t13 | t14);
    t15 = *((unsigned int *)t9);
    t16 = *((unsigned int *)t10);
    *((unsigned int *)t9) = (t15 | t16);
    goto LAB23;

LAB26:    t13 = *((unsigned int *)t7);
    t14 = *((unsigned int *)t8);
    *((unsigned int *)t7) = (t13 | t14);
    t15 = *((unsigned int *)t4);
    t16 = *((unsigned int *)t8);
    *((unsigned int *)t4) = (t15 | t16);
    goto LAB25;

LAB28:    t13 = *((unsigned int *)t7);
    t14 = *((unsigned int *)t8);
    *((unsigned int *)t7) = (t13 | t14);
    t15 = *((unsigned int *)t4);
    t16 = *((unsigned int *)t8);
    *((unsigned int *)t4) = (t15 | t16);
    goto LAB27;

LAB30:    t13 = *((unsigned int *)t7);
    t14 = *((unsigned int *)t8);
    *((unsigned int *)t7) = (t13 | t14);
    t15 = *((unsigned int *)t4);
    t16 = *((unsigned int *)t8);
    *((unsigned int *)t4) = (t15 | t16);
    goto LAB29;

LAB32:    t13 = *((unsigned int *)t7);
    t14 = *((unsigned int *)t8);
    *((unsigned int *)t7) = (t13 | t14);
    t15 = *((unsigned int *)t4);
    t16 = *((unsigned int *)t8);
    *((unsigned int *)t4) = (t15 | t16);
    goto LAB31;

LAB34:    t13 = *((unsigned int *)t7);
    t14 = *((unsigned int *)t8);
    *((unsigned int *)t7) = (t13 | t14);
    t15 = *((unsigned int *)t4);
    t16 = *((unsigned int *)t8);
    *((unsigned int *)t4) = (t15 | t16);
    goto LAB33;

LAB36:    t13 = *((unsigned int *)t7);
    t14 = *((unsigned int *)t8);
    *((unsigned int *)t7) = (t13 | t14);
    t15 = *((unsigned int *)t4);
    t16 = *((unsigned int *)t8);
    *((unsigned int *)t4) = (t15 | t16);
    goto LAB35;

LAB38:    t13 = *((unsigned int *)t7);
    t14 = *((unsigned int *)t8);
    *((unsigned int *)t7) = (t13 | t14);
    t15 = *((unsigned int *)t4);
    t16 = *((unsigned int *)t8);
    *((unsigned int *)t4) = (t15 | t16);
    goto LAB37;

}


extern void work_m_00000000002647839268_2309632077_init()
{
	static char *pe[] = {(void *)Always_8_0};
	xsi_register_didat("work_m_00000000002647839268_2309632077", "isim/TB_isim_beh.exe.sim/work/m_00000000002647839268_2309632077.didat");
	xsi_register_executes(pe);
}
