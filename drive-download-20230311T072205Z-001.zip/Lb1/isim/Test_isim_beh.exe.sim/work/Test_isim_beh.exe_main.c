/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

#include "xsi.h"

struct XSI_INFO xsi_info;



int main(int argc, char **argv)
{
    xsi_init_design(argc, argv);
    xsi_register_info(&xsi_info);

    xsi_register_min_prec_unit(-12);
    work_m_00000000002134114475_2389847537_init();
    unisims_ver_m_00000000002321652869_2814283601_init();
    unisims_ver_m_00000000003425732787_3126461646_init();
    unisims_ver_m_00000000001461499759_1414817250_init();
    unisims_ver_m_00000000001740809392_3445437528_init();
    unisims_ver_m_00000000003344785779_3356631773_init();
    unisims_ver_m_00000000001162476414_1323117156_init();
    unisims_ver_m_00000000001762375489_3501834183_init();
    work_m_00000000003491454899_2394137999_init();
    work_m_00000000000656438734_2247090866_init();
    work_m_00000000001209075331_2136638191_init();
    work_m_00000000003037257595_3597375865_init();
    work_m_00000000004134447467_2073120511_init();


    xsi_register_tops("work_m_00000000003037257595_3597375865");
    xsi_register_tops("work_m_00000000004134447467_2073120511");


    return xsi_run_simulation(argc, argv);

}
